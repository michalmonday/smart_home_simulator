Source:   
https://www.flaticon.com/packs/furniture-42  
