Pack provided by: Damaged Panda  
Source: https://opengameart.org/content/100-plus-game-sound-effects-wavoggm4a
